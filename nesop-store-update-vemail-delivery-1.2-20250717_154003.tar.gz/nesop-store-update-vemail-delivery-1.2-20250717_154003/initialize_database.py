#!/usr/bin/env python3
"""
Database Initialization Script for NESOP Store
Creates the basic database tables required for the application to function.
Run this before applying updates if the database is not initialized.
"""

import sqlite3
import os
import logging
from datetime import datetime

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
logger = logging.getLogger(__name__)

def get_database_path():
    """Get the database path"""
    # Check if we're in production environment
    production_path = "/opt/nesop-store/nesop_store.db"
    if os.path.exists("/opt/nesop-store/"):
        return production_path
    else:
        # Development environment
        return "nesop_store.db"

def initialize_database():
    """Initialize the database with all required tables"""
    
    db_path = get_database_path()
    logger.info(f"Initializing database at: {db_path}")
    
    try:
        # Create database directory if it doesn't exist
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Create users table
        logger.info("Creating users table...")
        cursor.execute('''CREATE TABLE IF NOT EXISTS users (
            username TEXT PRIMARY KEY,
            password TEXT NOT NULL,
            balance INTEGER DEFAULT 0,
            is_admin INTEGER DEFAULT 0,
            user_type TEXT DEFAULT 'local',
            ad_username TEXT,
            ad_domain TEXT,
            ad_display_name TEXT,
            ad_email TEXT,
            last_ad_sync TIMESTAMP,
            is_active INTEGER DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )''')
        
        # Create items table
        logger.info("Creating items table...")
        cursor.execute('''CREATE TABLE IF NOT EXISTS items (
            item TEXT PRIMARY KEY,
            description TEXT,
            price REAL,
            image TEXT,
            sold_out INTEGER DEFAULT 0,
            unlisted INTEGER DEFAULT 0
        )''')
        
        # Create purchases table
        logger.info("Creating purchases table...")
        cursor.execute('''CREATE TABLE IF NOT EXISTS purchases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            item TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            total_price REAL NOT NULL,
            purchase_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (username) REFERENCES users(username),
            FOREIGN KEY (item) REFERENCES items(item)
        )''')
        
        # Create reviews table
        logger.info("Creating reviews table...")
        cursor.execute('''CREATE TABLE IF NOT EXISTS reviews (
            review_id INTEGER PRIMARY KEY AUTOINCREMENT,
            item TEXT NOT NULL,
            username TEXT,
            rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
            review_text TEXT,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )''')
        
        # Create orders table (for email delivery functionality)
        logger.info("Creating orders table...")
        cursor.execute('''CREATE TABLE IF NOT EXISTS orders (
            order_id TEXT PRIMARY KEY,
            username TEXT NOT NULL,
            user_email TEXT,
            total_amount REAL NOT NULL,
            order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            status TEXT DEFAULT 'completed',
            email_sent INTEGER DEFAULT 0,
            FOREIGN KEY (username) REFERENCES users(username)
        )''')
        
        # Create order items table
        logger.info("Creating order_items table...")
        cursor.execute('''CREATE TABLE IF NOT EXISTS order_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id TEXT NOT NULL,
            item_name TEXT NOT NULL,
            item_price REAL NOT NULL,
            quantity INTEGER DEFAULT 1,
            FOREIGN KEY (order_id) REFERENCES orders(order_id)
        )''')
        
        # Create fallback admin user
        logger.info("Creating fallback admin user...")
        cursor.execute('''INSERT OR IGNORE INTO users (username, password, balance, is_admin) 
                         VALUES ('fallback_admin', 'ChangeMe123!', 1000, 1)''')
        
        # Add some sample items if none exist
        cursor.execute("SELECT COUNT(*) FROM items")
        item_count = cursor.fetchone()[0]
        
        if item_count == 0:
            logger.info("Adding sample items...")
            sample_items = [
                ('Sample T-Shirt', 'NESOP branded t-shirt', 25.0, 'placeholder.png', 0, 0),
                ('Sample Mug', 'NESOP branded mug', 15.0, 'placeholder.png', 0, 0),
                ('Sample Notebook', 'NESOP branded notebook', 10.0, 'placeholder.png', 0, 0)
            ]
            
            cursor.executemany('''INSERT OR IGNORE INTO items (item, description, price, image, sold_out, unlisted) 
                                 VALUES (?, ?, ?, ?, ?, ?)''', sample_items)
        
        conn.commit()
        conn.close()
        
        logger.info("✓ Database initialized successfully!")
        logger.info(f"✓ Database location: {db_path}")
        logger.info("✓ All required tables created")
        logger.info("✓ Fallback admin user created (username: fallback_admin, password: ChangeMe123!)")
        logger.info("✓ Sample items added")
        
        return True
        
    except Exception as e:
        logger.error(f"Failed to initialize database: {str(e)}")
        return False

def check_database_status():
    """Check if the database is properly initialized"""
    
    db_path = get_database_path()
    
    if not os.path.exists(db_path):
        logger.warning(f"Database file does not exist: {db_path}")
        return False
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Check if all required tables exist
        required_tables = ['users', 'items', 'purchases', 'reviews', 'orders', 'order_items']
        existing_tables = []
        
        for table in required_tables:
            cursor.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{table}'")
            if cursor.fetchone():
                existing_tables.append(table)
        
        conn.close()
        
        logger.info(f"Database status check for: {db_path}")
        logger.info(f"Required tables: {required_tables}")
        logger.info(f"Existing tables: {existing_tables}")
        
        if len(existing_tables) == len(required_tables):
            logger.info("✓ Database is properly initialized")
            return True
        else:
            missing_tables = set(required_tables) - set(existing_tables)
            logger.warning(f"✗ Missing tables: {missing_tables}")
            return False
            
    except Exception as e:
        logger.error(f"Failed to check database status: {str(e)}")
        return False

def main():
    """Main function"""
    print("NESOP Store Database Initialization")
    print("=" * 40)
    
    # Check current status
    print("\n1. Checking current database status...")
    is_initialized = check_database_status()
    
    if is_initialized:
        print("\n✓ Database is already properly initialized!")
        print("You can proceed with applying updates.")
    else:
        print("\n✗ Database needs initialization.")
        
        # Ask for confirmation
        response = input("\nWould you like to initialize the database now? (y/N): ").strip().lower()
        
        if response in ['y', 'yes']:
            print("\n2. Initializing database...")
            success = initialize_database()
            
            if success:
                print("\n✓ Database initialization completed successfully!")
                print("\nNext steps:")
                print("1. Change the fallback admin password")
                print("2. Apply your update package")
                print("3. Configure email settings if using email delivery")
            else:
                print("\n✗ Database initialization failed!")
                print("Please check the error messages above.")
        else:
            print("\nDatabase initialization cancelled.")

if __name__ == "__main__":
    main() 